# convert_data.py - Convert your rods.json to the new format

import json
import os
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).parent
DATABASE_DIR = BASE_DIR / "database"
RODS_JSON = DATABASE_DIR / "rods.json"
PRODUCTS_JSON = DATABASE_DIR / "products.json"

def convert_rods_to_products():
    """Convert your existing rods.json to the new products format"""
    
    if not RODS_JSON.exists():
        print(f"Error: {RODS_JSON} not found!")
        return False
    
    try:
        # Load your existing rods data
        with open(RODS_JSON, 'r', encoding='utf-8') as f:
            rods_data = json.load(f)
        
        products = []
        categories = set()
        brands = set()
        
        print(f"Converting {len(rods_data)} rods to products...")
        
        for i, rod in enumerate(rods_data):
            # Skip empty rows
            if not rod or all(v is None or str(v).strip() == '' for v in rod.values()):
                continue
            
            # Create product ID from Item Code
            item_code = rod.get('Item Code', '').strip()
            if not item_code:
                item_code = f"ROD-{i+1:03d}"
            
            # Create product object
            product = {
                "id": item_code,
                "sku": item_code,
                "title": f"{rod.get('Brand', '')} {rod.get('Model', '')}".strip(),
                "brand": rod.get('Brand', '').strip(),
                "model": rod.get('Model', '').strip(),
                "category": "Rods",
                "subcategory": rod.get('Type', '').strip(),
                "description": generate_description(rod),
                "price": parse_price(rod.get('Price', '0')),
                "discount": parse_discount(rod.get('Discount', '0')),
                "final_price": parse_price(rod.get('Final Price', rod.get('Price', '0'))),
                "specifications": extract_specifications(rod),
                "images": [f"/static/product_images/{item_code}/1.jpg"],  # Default image
                "in_stock": True,
                "created_at": 1704067200,  # Fixed timestamp
                "updated_at": 1704067200
            }
            
            products.append(product)
            categories.add("Rods")
            if product["brand"]:
                brands.add(product["brand"])
            
            print(f"  - Converted: {product['title']}")
        
        # Create final data structure
        products_data = {
            "products": products,
            "categories": sorted(list(categories)),
            "brands": sorted(list(brands)),
            "total_products": len(products),
            "last_updated": 1704067200
        }
        
        # Save to products.json
        with open(PRODUCTS_JSON, 'w', encoding='utf-8') as f:
            json.dump(products_data, f, indent=2, ensure_ascii=False)
        
        print(f"\n✅ Successfully converted {len(products)} products!")
        print(f"📁 Data saved to: {PRODUCTS_JSON}")
        print(f"🏷️  Categories: {products_data['categories']}")
        print(f"🔤 Brands: {products_data['brands']}")
        
        return True
        
    except Exception as e:
        print(f"❌ Error converting data: {e}")
        return False

def generate_description(rod):
    """Generate a product description from rod data"""
    specs = []
    if rod.get("Length"):
        specs.append(f"Length: {rod['Length']}")
    if rod.get("Power"):
        specs.append(f"Power: {rod['Power']}")
    if rod.get("Action"):
        specs.append(f"Action: {rod['Action']}")
    
    desc = f"Premium fishing rod designed for optimal performance. "
    if specs:
        desc += f"Features include: {', '.join(specs)}. "
    desc += "Ideal for both amateur and professional anglers."
    
    return desc

def parse_price(price_str):
    """Convert price string to float"""
    try:
        cleaned = str(price_str).replace('RM', '').replace('$', '').replace(',', '').strip()
        return float(cleaned) if cleaned else 0.0
    except:
        return 0.0

def parse_discount(discount_str):
    """Convert discount string to percentage float"""
    try:
        cleaned = str(discount_str).replace('%', '').strip()
        return float(cleaned) / 100 if cleaned else 0.0
    except:
        return 0.0

def extract_specifications(rod):
    """Extract specifications into a structured dictionary"""
    specs = {}
    
    # Standard specifications mapping
    spec_mapping = {
        "Item Code": "SKU",
        "Brand": "Brand",
        "Model": "Model",
        "Type": "Type",
        "Reel type": "Reel Type",
        "Length": "Length",
        "Joint Type": "Joint Type",
        "Power": "Power",
        "Lure Weight": "Lure Weight",
        "Action": "Action",
        "Material": "Material",
        "Guide": "Guide Type",
        "Reel Seat": "Reel Seat",
        "Warranty": "Warranty",
        "CR": "CR",
        "GV": "GV"
    }
    
    for key, display_name in spec_mapping.items():
        if key in rod and rod[key]:
            specs[display_name] = str(rod[key]).strip()
    
    return specs

if __name__ == "__main__":
    convert_rods_to_products()