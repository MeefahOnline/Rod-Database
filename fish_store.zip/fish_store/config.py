# config.py - Application Configuration

import os
from pathlib import Path

# Base directory
BASE_DIR = Path(__file__).parent

# Database paths
DATABASE_DIR = BASE_DIR / "database"
PRODUCTS_JSON = DATABASE_DIR / "products.json"
RODS_JSON = DATABASE_DIR / "rods.json"  # Your existing file
IMAGE_MAPPING_JSON = DATABASE_DIR / "image_mapping.json"

# Image paths
STATIC_DIR = BASE_DIR / "static"
PRODUCT_IMAGES_DIR = STATIC_DIR / "product_images"

# Template paths
TEMPLATES_DIR = BASE_DIR / "templates"

# Application settings
class Config:
    # Website Settings
    SITE_NAME = "MEEFAH TACKLE"
    SITE_URL = "http://localhost:5000"
    
    # Security
    SECRET_KEY = "your-secret-key-here-change-this"  # Change this!
    
    # Product Settings
    MAX_IMAGES_PER_PRODUCT = 10
    ALLOWED_IMAGE_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.gif', '.webp'}
    
    # Pagination
    PRODUCTS_PER_PAGE = 20
    
    # Image processing
    THUMBNAIL_SIZE = (300, 300)
    MEDIUM_SIZE = (600, 600)
    LARGE_SIZE = (1200, 1200)
    
    # Cache settings
    CACHE_TIMEOUT = 300  # 5 minutes
    
    @staticmethod
    def init_app():
        # Create necessary directories
        DATABASE_DIR.mkdir(exist_ok=True)
        PRODUCT_IMAGES_DIR.mkdir(exist_ok=True)
        (STATIC_DIR / "css").mkdir(exist_ok=True)
        (STATIC_DIR / "js").mkdir(exist_ok=True)
        (TEMPLATES_DIR / "partials").mkdir(exist_ok=True)

# Initialize directories
Config.init_app()

# Export configuration
config = Config()