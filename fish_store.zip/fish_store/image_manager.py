# image_manager.py - Manage product images (No PIL dependency version)

import shutil
import os
from pathlib import Path
from typing import List, Optional
import base64

from config import config, PRODUCT_IMAGES_DIR

class ProductImageManager:
    """Manage product images and folder structure - No PIL version"""
    
    def __init__(self):
        self.base_dir = PRODUCT_IMAGES_DIR
    
    def create_product_folder(self, product_code: str) -> Path:
        """Create a folder for a product's images"""
        folder_path = self.base_dir / product_code
        folder_path.mkdir(exist_ok=True, parents=True)
        return folder_path
    
    def get_product_images(self, product_code: str) -> List[str]:
        """Get all images for a product"""
        folder_path = self.base_dir / product_code
        images = []
        
        if folder_path.exists() and folder_path.is_dir():
            try:
                # Get all files in the directory
                for file in folder_path.iterdir():
                    if file.is_file():
                        ext = file.suffix.lower()
                        if ext in config.ALLOWED_IMAGE_EXTENSIONS:
                            images.append(file.name)
            except Exception as e:
                print(f"Error reading images from {product_code}: {e}")
        
        return sorted(images)
    
    def get_image_urls(self, product_code: str) -> List[str]:
        """Get web URLs for product images"""
        images = self.get_product_images(product_code)
        return [f"/static/product_images/{product_code}/{img}" for img in images]
    
    def upload_image(self, product_code: str, image_data: bytes, 
                    image_number: int = 1, image_format: str = "jpg") -> bool:
        """Upload an image for a product"""
        try:
            folder_path = self.create_product_folder(product_code)
            
            # Validate image format
            if f".{image_format.lower()}" not in config.ALLOWED_IMAGE_EXTENSIONS:
                image_format = "jpg"
            
            # Save original
            filename = f"{image_number}.{image_format}"
            filepath = folder_path / filename
            
            with open(filepath, 'wb') as f:
                f.write(image_data)
            
            return True
            
        except Exception as e:
            print(f"Error uploading image: {e}")
            return False
    
    def upload_image_from_base64(self, product_code: str, base64_string: str,
                                image_number: int = 1, image_format: str = "jpg") -> bool:
        """Upload an image from base64 string"""
        try:
            # Remove data URL prefix if present
            if ',' in base64_string:
                base64_string = base64_string.split(',')[1]
            
            # Decode base64
            image_data = base64.b64decode(base64_string)
            
            return self.upload_image(product_code, image_data, image_number, image_format)
            
        except Exception as e:
            print(f"Error uploading base64 image: {e}")
            return False
    
    def upload_image_from_file(self, product_code: str, file_path: str,
                              image_number: int = 1) -> bool:
        """Upload an image from a file path"""
        try:
            with open(file_path, 'rb') as f:
                image_data = f.read()
            
            # Get file extension
            ext = Path(file_path).suffix.lower().replace('.', '')
            if not ext or f".{ext}" not in config.ALLOWED_IMAGE_EXTENSIONS:
                ext = "jpg"
            
            return self.upload_image(product_code, image_data, image_number, ext)
            
        except Exception as e:
            print(f"Error uploading image from file: {e}")
            return False
    
    def copy_image(self, product_code: str, source_path: str,
                  image_number: int = 1) -> bool:
        """Copy an image file to product folder"""
        try:
            folder_path = self.create_product_folder(product_code)
            
            source = Path(source_path)
            if not source.exists():
                return False
            
            # Get file extension
            ext = source.suffix.lower()
            if ext not in config.ALLOWED_IMAGE_EXTENSIONS:
                return False
            
            # Create new filename
            filename = f"{image_number}{ext}"
            dest_path = folder_path / filename
            
            # Copy the file
            shutil.copy2(source_path, dest_path)
            
            return True
            
        except Exception as e:
            print(f"Error copying image: {e}")
            return False
    
    def delete_product_images(self, product_code: str) -> bool:
        """Delete all images for a product"""
        try:
            folder_path = self.base_dir / product_code
            if folder_path.exists() and folder_path.is_dir():
                shutil.rmtree(folder_path)
            return True
        except Exception as e:
            print(f"Error deleting images: {e}")
            return False
    
    def delete_single_image(self, product_code: str, image_filename: str) -> bool:
        """Delete a single image"""
        try:
            image_path = self.base_dir / product_code / image_filename
            if image_path.exists() and image_path.is_file():
                image_path.unlink()
                return True
            return False
        except Exception as e:
            print(f"Error deleting image {image_filename}: {e}")
            return False
    
    def get_main_image_url(self, product_code: str) -> str:
        """Get URL of the main product image"""
        images = self.get_image_urls(product_code)
        if images:
            return images[0]
        return "/static/images/placeholder.jpg"
    
    def get_image_count(self, product_code: str) -> int:
        """Get number of images for a product"""
        return len(self.get_product_images(product_code))
    
    def has_images(self, product_code: str) -> bool:
        """Check if product has any images"""
        return self.get_image_count(product_code) > 0
    
    def get_image_info(self, product_code: str) -> List[dict]:
        """Get information about all images for a product"""
        images = self.get_product_images(product_code)
        result = []
        
        for i, img_name in enumerate(images, 1):
            img_path = self.base_dir / product_code / img_name
            if img_path.exists():
                result.append({
                    "number": i,
                    "filename": img_name,
                    "url": f"/static/product_images/{product_code}/{img_name}",
                    "size": img_path.stat().st_size if img_path.exists() else 0,
                    "extension": Path(img_name).suffix.lower()
                })
        
        return result
    
    def create_placeholder_image(self, product_code: str, text: str = None) -> bool:
        """Create a simple placeholder image (text-based)"""
        try:
            if not text:
                text = product_code
            
            folder_path = self.create_product_folder(product_code)
            placeholder_path = folder_path / "1.jpg"
            
            # Create a simple HTML file that acts as a placeholder
            # This is a fallback until real images are added
            html_content = f'''<!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {{ margin: 0; padding: 0; display: flex; align-items: center; justify-content: center; height: 100vh; background: #f0f0f0; font-family: Arial, sans-serif; }}
                    .placeholder {{ text-align: center; padding: 20px; }}
                    .placeholder-text {{ font-size: 24px; color: #333; margin-bottom: 10px; }}
                    .placeholder-subtext {{ font-size: 14px; color: #666; }}
                </style>
            </head>
            <body>
                <div class="placeholder">
                    <div class="placeholder-text">{text}</div>
                    <div class="placeholder-subtext">Image Coming Soon</div>
                </div>
            </body>
            </html>'''
            
            with open(placeholder_path, 'w') as f:
                f.write(html_content)
            
            # Rename to .html if needed, but for now keep as .jpg
            # The actual implementation would use a real image generator
            
            return True
            
        except Exception as e:
            print(f"Error creating placeholder: {e}")
            return False
    
    def scan_all_products(self) -> dict:
        """Scan and return all products with their images"""
        products_data = {}
        
        if not self.base_dir.exists():
            return products_data
        
        for product_folder in self.base_dir.iterdir():
            if product_folder.is_dir():
                product_code = product_folder.name
                images = self.get_product_images(product_code)
                products_data[product_code] = {
                    "image_count": len(images),
                    "images": images,
                    "has_images": len(images) > 0
                }
        
        return products_data

# Create a global instance
image_manager = ProductImageManager()