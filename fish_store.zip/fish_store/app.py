﻿# app.py - MEEFAH TACKLE Fishing Equipment Store
from flask import Flask, render_template, jsonify, request, send_from_directory, json
import requests
import time
import json
import os
from pathlib import Path

# ============================================
# CONFIGURATION - EDIT ALL TEXT DIRECTLY HERE
# ============================================

# Company Information
COMPANY_NAME = "MEEFAH TACKLE"
COMPANY_FONT_FAMILY = "Calibri"
COMPANY_FONT_STYLE = "italic"
COMPANY_FONT_WEIGHT = "700"
COMPANY_ESTABLISHED_YEAR = "1987"
COMPANY_LOGO_PATH = "/static/images/logo.jpg"

# Contact Information
CONTACT_ADDRESS_LINE1 = "1 Jalan SP1"
CONTACT_ADDRESS_LINE2 = "Taman S mabok Perdana, 75150"
CONTACT_ADDRESS_LINE3 = "Melaka, Malaysia"
CONTACT_PHONE = "06 288 2055"
CONTACT_EMAIL = "meefahonline@gmail.com"
CONTACT_HOURS_MON_FRI = "11:00 AM - 7:00 PM"
CONTACT_HOURS_SAT = "11:00 AM - 7:00 PM"
CONTACT_HOURS_SUN = "11:00 AM - 7:00 PM"

# Homepage Gallery Images
HOMEPAGE_GALLERY1_IMAGE = "/static/images/gallery/gallery1.jpg"
HOMEPAGE_GALLERY2_IMAGE = "/static/images/gallery/gallery2.jpg"
HOMEPAGE_GALLERY3_IMAGE = "/static/images/gallery/gallery3.jpg"
HOMEPAGE_GALLERY4_IMAGE = "/static/images/gallery/gallery4.jpg"

# Homepage Categories
HOMEPAGE_CATEGORY1_IMAGE = "/static/images/category/category1.jpg"
HOMEPAGE_CATEGORY1_TITLE = "Fishing Rods"
HOMEPAGE_CATEGORY1_DESCRIPTION = "Browse our complete collection of premium fishing rods for all types of fishing"

HOMEPAGE_CATEGORY2_IMAGE = "/static/images/category/category2.jpg"
HOMEPAGE_CATEGORY2_TITLE = "Fishing Reels"
HOMEPAGE_CATEGORY2_DESCRIPTION = "Spinning, baitcasting, and conventional reels from top brands"

HOMEPAGE_CATEGORY3_IMAGE = "/static/images/category/category3.jpg"
HOMEPAGE_CATEGORY3_TITLE = "Tackle & Accessories"
HOMEPAGE_CATEGORY3_DESCRIPTION = "Hooks, lines, lures, and all essential fishing accessories"

HOMEPAGE_CATEGORY4_IMAGE = "/static/images/category/category4.jpg"
HOMEPAGE_CATEGORY4_TITLE = "Fishing Apparel"
HOMEPAGE_CATEGORY4_DESCRIPTION = "Fishing shirts, hats, waterproof gear and protective clothing"

# Homepage Featured Products
HOMEPAGE_FEATURED1_TITLE = "Shimano Calcutta Conquest BFS"
HOMEPAGE_FEATURED1_DESCRIPTION = "Small Size, Big Performance. For the thrillseekers"
HOMEPAGE_FEATURED1_PRICE = "RM 2,299.00"
HOMEPAGE_FEATURED1_IMAGE = "/static/images/featured/featured1.jpg"

HOMEPAGE_FEATURED2_TITLE = "Daiwa Tatula SV TW 103"
HOMEPAGE_FEATURED2_DESCRIPTION = "Advanced baitcasting reel with SV spool technology for effortless casting and superior control."
HOMEPAGE_FEATURED2_PRICE = "RM 1,499.00"
HOMEPAGE_FEATURED2_IMAGE = "/static/images/featured/featured2.jpg"

HOMEPAGE_FEATURED3_TITLE = "Shimano Tranx 401"
HOMEPAGE_FEATURED3_DESCRIPTION = "Large sized baitcaster designed for fishing in the toughest environment."
HOMEPAGE_FEATURED3_PRICE = "RM 1,250"
HOMEPAGE_FEATURED3_IMAGE = "/static/images/featured/featured3.jpg"

# Styling
STYLING_PRIMARY_COLOR = "#0b1f3a"
STYLING_SECONDARY_COLOR = "#1f3c88"
STYLING_ACCENT_COLOR = "#ff6b35"
STYLING_BACKGROUND_COLOR = "#f8fafc"
STYLING_TEXT_COLOR = "#333333"
STYLING_NAV_HEIGHT = "120px"
STYLING_FONT_SIZE_NAV = "42px"
STYLING_FONT_SIZE_TITLE = "36px"
STYLING_FONT_SIZE_BODY = "16px"

# ============================================
# DATA LOADING FUNCTIONS
# ============================================

# Cache setup for GitHub data
_data_cache = None
_cache_time = 0
CACHE_DURATION = 300

def is_empty_row(rod):
    """Check if a row is completely empty"""
    if not rod:
        return True
    
    for key, value in rod.items():
        if value is None:
            continue
            
        str_value = str(value).strip().lower()
        
        if str_value and str_value != "0" and str_value != "0.0" and str_value != "0.00":
            return False
    
    return True

def clean_json_keys(data):
    """Clean spaces from JSON keys"""
    if isinstance(data, dict):
        cleaned = {}
        for key, value in data.items():
            if isinstance(key, str):
                cleaned[key.strip()] = clean_json_keys(value)
            else:
                cleaned[key] = clean_json_keys(value)
        return cleaned
    elif isinstance(data, list):
        return [clean_json_keys(item) for item in data]
    else:
        return data

def normalize_column_name(key):
    """Normalize column names to standard format"""
    if not key:
        return key
    
    clean_key = str(key).strip()
    
    variations = {
        'itemcode': 'Item Code',
        'item code': 'Item Code',
        'ItemCode': 'Item Code',
        'item_code': 'Item Code',
        'brand': 'Brand',
        'model': 'Model',
        'type': 'Type',
        'reeltype': 'Reel type',
        'reel type': 'Reel type',
        'reel_type': 'Reel type',
        'ReelType': 'Reel type',
        'length': 'Length',
        'jointtype': 'Joint Type',
        'joint type': 'Joint Type',
        'joint_type': 'Joint Type',
        'JointType': 'Joint Type',
        'power': 'Power',
        'lureweight': 'Lure Weight',
        'lure weight': 'Lure Weight',
        'lure_weight': 'Lure Weight',
        'LureWeight': 'Lure Weight',
        'action': 'Action',
        'material': 'Material',
        'guide': 'Guide',
        'reelseat': 'Reel Seat',
        'reel seat': 'Reel Seat',
        'reel_seat': 'Reel Seat',
        'ReelSeat': 'Reel Seat',
        'price': 'Price',
        'discount': 'Discount',
        'cr': 'CR',
        'gv': 'GV',
        'warranty': 'Warranty',
        'afterdiscount': 'After Discount',
        'after discount': 'After Discount',
        'after_discount': 'After Discount',
        'AfterDiscount': 'After Discount',
        'finalprice': 'Final Price',
        'final price': 'Final Price',
        'final_price': 'Final Price',
        'FinalPrice': 'Final Price',
    }
    
    return variations.get(clean_key.lower(), clean_key)

def create_sample_data():
    """Create sample rod data"""
    return [
        {
            "Item Code": "SHIM-001",
            "Brand": "Shimano",
            "Model": "Teramar TMS-X70M",
            "Type": "Spinning",
            "Reel type": "Spinning",
            "Length": "7'0\"",
            "Joint Type": "2-piece",
            "Power": "Medium",
            "Lure Weight": "1/4-3/4 oz",
            "Action": "Fast",
            "Material": "Carbon Fiber",
            "Guide": "Fuji Alconite",
            "Reel Seat": "Fuji DPS",
            "Price": "179.99",
            "Discount": "10%",
            "CR": "Yes",
            "GV": "No",
            "Warranty": "1 year",
            "After Discount": "161.99",
            "Final Price": "161.99"
        }
    ]

def load_rods_data():
    """Fetch rods data from GitHub with caching"""
    global _data_cache, _cache_time
    
    if _data_cache and time.time() - _cache_time < CACHE_DURATION:
        return _data_cache
    
    try:
        github_url = "https://raw.githubusercontent.com/MeefahOnline/Rod-Database/main/Rod%20Data.json"
        
        response = requests.get(github_url, timeout=15)
        response.raise_for_status()
        
        # Handle UTF-8 BOM
        content = response.content.decode('utf-8-sig')
        rods = json.loads(content)
        
        rods = clean_json_keys(rods)
        
        if not isinstance(rods, list):
            rods = [rods]
        
        cleaned_rods = []
        for rod in rods:
            normalized_rod = {}
            for key, value in rod.items():
                normalized_key = normalize_column_name(key)
                normalized_rod[normalized_key] = value
            
            has_data = False
            for value in normalized_rod.values():
                if value is None:
                    continue
                str_value = str(value).strip()
                if str_value and str_value.lower() not in ['', '0', '0.0', '0.00', 'null', 'nan']:
                    has_data = True
                    break
            
            if has_data:
                cleaned_rods.append(normalized_rod)
        
        _data_cache = cleaned_rods
        _cache_time = time.time()
        
        return cleaned_rods
        
    except requests.exceptions.RequestException:
        return create_sample_data()
    except json.JSONDecodeError:
        return create_sample_data()
    except Exception:
        if _data_cache:
            return _data_cache
        return create_sample_data()

# ============================================
# FLASK APPLICATION
# ============================================

app = Flask(__name__)

# ============================================
# ROUTES
# ============================================

@app.route('/')
def home():
    """Homepage"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - Premium Fishing Equipment</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=5">
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .gallery-section {{
                width: 100%;
                margin: 0;
                padding: 0;
                position: relative;
            }}
            .gallery-container {{
                position: relative;
                width: 100%;
                height: 600px;
                overflow: hidden;
                border-radius: 0;
                box-shadow: 0 5px 20px rgba(0,0,0,0.15);
                background: {STYLING_PRIMARY_COLOR};
                margin: 0;
            }}
            .gallery-slides {{
                display: flex;
                width: 400%;
                height: 100%;
                transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            }}
            .gallery-slide {{
                width: 25%;
                height: 100%;
                flex-shrink: 0;
                position: relative;
            }}
            .gallery-image {{
                width: 100%;
                height: 100%;
                object-fit: cover;
                display: block;
            }}
            .gallery-nav {{
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                background: rgba(255, 255, 255, 0.2);
                border: none;
                color: white;
                width: 60px;
                height: 60px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                z-index: 100;
                transition: all 0.3s ease;
                font-size: 24px;
                backdrop-filter: blur(5px);
                -webkit-backdrop-filter: blur(5px);
                margin: 0;
                padding: 0;
            }}
            .gallery-nav:hover {{
                background: rgba(255, 255, 255, 0.3);
                transform: translateY(-50%) scale(1.1);
            }}
            .gallery-nav.prev {{
                left: 30px;
            }}
            .gallery-nav.next {{
                right: 30px;
            }}
            .gallery-dots {{
                position: absolute;
                bottom: 30px;
                left: 0;
                right: 0;
                display: flex;
                justify-content: center;
                gap: 12px;
                z-index: 100;
            }}
            .gallery-dot {{
                width: 14px;
                height: 14px;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.4);
                border: 2px solid rgba(255, 255, 255, 0.6);
                cursor: pointer;
                transition: all 0.3s ease;
            }}
            .gallery-dot:hover {{
                background: rgba(255, 255, 255, 0.6);
                transform: scale(1.2);
            }}
            .gallery-dot.active {{
                background: white;
                border-color: white;
                transform: scale(1.2);
            }}
            .links-section {{
                max-width: 1400px;
                margin: 60px auto;
                padding: 0 20px;
            }}
            .links-title {{
                text-align: center;
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 40px 0;
                font-weight: 600;
            }}
            .links-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 30px;
            }}
            .link-box {{
                background: white;
                border-radius: 15px;
                padding: 30px 25px;
                text-align: center;
                text-decoration: none;
                color: {STYLING_PRIMARY_COLOR};
                transition: all 0.3s;
                border: 2px solid #e9ecef;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 220px;
            }}
            .link-box:hover {{
                transform: translateY(-10px);
                border-color: {STYLING_SECONDARY_COLOR};
                box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            }}
            .link-image {{
                width: 180px;
                height: 180px;
                object-fit: cover;
                border-radius: 15px;
                margin-bottom: 20px;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
                transition: transform 0.3s;
            }}
            .link-box:hover .link-image {{
                transform: scale(1.05);
            }}
            .link-box h3 {{
                margin: 0 0 10px 0;
                font-size: 22px;
                font-weight: 600;
            }}
            .link-box p {{
                margin: 0;
                color: #666;
                font-size: 15px;
                line-height: 1.5;
            }}
            .featured-section {{
                max-width: 1400px;
                margin: 60px auto;
                padding: 0 20px;
            }}
            .featured-title {{
                text-align: center;
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 40px 0;
                font-weight: 600;
            }}
            .featured-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
                gap: 40px;
            }}
            .featured-item {{
                background: white;
                border-radius: 15px;
                overflow: hidden;
                transition: all 0.25s ease;
                border: 2px solid #e9ecef;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
                text-decoration: none;
                color: inherit;
                display: block;
                will-change: transform;
            }}
            .featured-item:hover {{
                transform: translateY(-8px);
                border-color: {STYLING_SECONDARY_COLOR};
                box-shadow: 0 12px 25px rgba(0,0,0,0.12);
            }}
            .featured-image {{
                width: 100%;
                height: 350px;
                object-fit: cover;
                display: block;
                background: {STYLING_PRIMARY_COLOR};
                image-rendering: -webkit-optimize-contrast;
                image-rendering: crisp-edges;
                -ms-interpolation-mode: nearest-neighbor;
                -webkit-font-smoothing: antialiased;
                -moz-osx-font-smoothing: grayscale;
                transform: translateZ(0);
                -webkit-backface-visibility: hidden;
                backface-visibility: hidden;
                max-width: 100%;
                max-height: 100%;
            }}
            .featured-content {{
                padding: 25px;
            }}
            .featured-content h3 {{
                margin: 0 0 10px 0;
                color: {STYLING_PRIMARY_COLOR};
                font-size: 22px;
                font-weight: 600;
            }}
            .featured-content p {{
                margin: 0 0 15px 0;
                color: #666;
                line-height: 1.6;
                font-size: 15px;
            }}
            .featured-price {{
                color: {STYLING_SECONDARY_COLOR};
                font-size: 20px;
                font-weight: 700;
                margin: 0;
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .gallery-container {{
                    height: 400px;
                }}
                .gallery-nav {{
                    width: 50px;
                    height: 50px;
                    font-size: 20px;
                }}
                .gallery-nav.prev {{
                    left: 15px;
                }}
                .gallery-nav.next {{
                    right: 15px;
                }}
                .gallery-dots {{
                    bottom: 20px;
                }}
                .gallery-dot {{
                    width: 12px;
                    height: 12px;
                }}
                .links-title, .featured-title {{
                    font-size: 28px;
                }}
                .links-grid, .featured-grid {{
                    grid-template-columns: 1fr;
                    gap: 20px;
                }}
                .link-box {{
                    padding: 25px 20px;
                    min-height: 200px;
                }}
                .link-image {{
                    width: 140px;
                    height: 140px;
                }}
                .link-box h3 {{
                    font-size: 20px;
                }}
                .featured-item {{
                    max-width: 400px;
                    margin: 0 auto;
                }}
                .featured-image {{
                    height: 350px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
            @media (max-width: 480px) {{
                .gallery-nav {{
                    width: 40px;
                    height: 40px;
                    font-size: 18px;
                }}
                .gallery-nav.prev {{
                    left: 10px;
                }}
                .gallery-nav.next {{
                    right: 10px;
                }}
                .gallery-dots {{
                    bottom: 15px;
                }}
                .gallery-dot {{
                    width: 10px;
                    height: 10px;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link active">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <section class="gallery-section">
            <div class="gallery-container">
                <div class="gallery-slides" id="gallerySlides">
                    <div class="gallery-slide">
                        <img src="{HOMEPAGE_GALLERY1_IMAGE}" alt="" class="gallery-image" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1567899378497-8e2cda46648d?w=1200&h=500&fit=crop'; this.alt=''">
                    </div>
                    <div class="gallery-slide">
                        <img src="{HOMEPAGE_GALLERY2_IMAGE}" alt="" class="gallery-image" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1555529669-e69e7aa0ba9a?w=1200&h=500&fit=crop'; this.alt=''">
                    </div>
                    <div class="gallery-slide">
                        <img src="{HOMEPAGE_GALLERY3_IMAGE}" alt="" class="gallery-image" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1530041539828-114de669390e?w=1200&h=500&fit=crop'; this.alt=''">
                    </div>
                    <div class="gallery-slide">
                        <img src="{HOMEPAGE_GALLERY4_IMAGE}" alt="" class="gallery-image" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1601512444021-0410c3c7d1b8?w=1200&h=500&fit=crop'; this.alt=''">
                    </div>
                </div>
                
                <!-- Navigation Arrows -->
                <button class="gallery-nav prev" id="prevBtn">‹</button>
                <button class="gallery-nav next" id="nextBtn">›</button>
                
                <!-- Dots Navigation -->
                <div class="gallery-dots" id="galleryDots">
                    <div class="gallery-dot active" data-slide="0"></div>
                    <div class="gallery-dot" data-slide="1"></div>
                    <div class="gallery-dot" data-slide="2"></div>
                    <div class="gallery-dot" data-slide="3"></div>
                </div>
            </div>
        </section>
        
        <section class="links-section">
            <h2 class="links-title">Shop By Category</h2>
            <div class="links-grid">
                <a href="/catalog" class="link-box">
                    <img src="{HOMEPAGE_CATEGORY1_IMAGE}" alt="{HOMEPAGE_CATEGORY1_TITLE}" class="link-image">
                    <h3>{HOMEPAGE_CATEGORY1_TITLE}</h3>
                    <p>{HOMEPAGE_CATEGORY1_DESCRIPTION}</p>
                </a>
                <a href="/reels" class="link-box">
                    <img src="{HOMEPAGE_CATEGORY2_IMAGE}" alt="{HOMEPAGE_CATEGORY2_TITLE}" class="link-image">
                    <h3>{HOMEPAGE_CATEGORY2_TITLE}</h3>
                    <p>{HOMEPAGE_CATEGORY2_DESCRIPTION}</p>
                </a>
                <a href="/accessories" class="link-box">
                    <img src="{HOMEPAGE_CATEGORY3_IMAGE}" alt="{HOMEPAGE_CATEGORY3_TITLE}" class="link-image">
                    <h3>{HOMEPAGE_CATEGORY3_TITLE}</h3>
                    <p>{HOMEPAGE_CATEGORY3_DESCRIPTION}</p>
                </a>
                <a href="/apparel" class="link-box">
                    <img src="{HOMEPAGE_CATEGORY4_IMAGE}" alt="{HOMEPAGE_CATEGORY4_TITLE}" class="link-image">
                    <h3>{HOMEPAGE_CATEGORY4_TITLE}</h3>
                    <p>{HOMEPAGE_CATEGORY4_DESCRIPTION}</p>
                </a>
            </div>
        </section>
        
        <section class="featured-section">
            <h2 class="featured-title">Featured Products</h2>
            <div class="featured-grid">
                <a href="/catalog" class="featured-item">
                    <img 
                        src="{HOMEPAGE_FEATURED1_IMAGE}" 
                        alt="{HOMEPAGE_FEATURED1_TITLE}" 
                        class="featured-image"
                        loading="lazy"
                        width="350"
                        height="350"
                        onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=350&h=350&fit=crop&q=80'; this.alt='Fishing Rod'"
                    >
                    <div class="featured-content">
                        <h3>{HOMEPAGE_FEATURED1_TITLE}</h3>
                        <p>{HOMEPAGE_FEATURED1_DESCRIPTION}</p>
                        <p class="featured-price">{HOMEPAGE_FEATURED1_PRICE}</p>
                    </div>
                </a>
                <a href="/catalog" class="featured-item">
                    <img 
                        src="{HOMEPAGE_FEATURED2_IMAGE}" 
                        alt="{HOMEPAGE_FEATURED2_TITLE}" 
                        class="featured-image"
                        loading="lazy"
                        width="350"
                        height="350"
                        onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1593811167562-9cef47c2118c?w=350&h=350&fit=crop&q=80'; this.alt='Fishing Reel'"
                    >
                    <div class="featured-content">
                        <h3>{HOMEPAGE_FEATURED2_TITLE}</h3>
                        <p>{HOMEPAGE_FEATURED2_DESCRIPTION}</p>
                        <p class="featured-price">{HOMEPAGE_FEATURED2_PRICE}</p>
                    </div>
                </a>
                <a href="/catalog" class="featured-item">
                    <img 
                        src="{HOMEPAGE_FEATURED3_IMAGE}" 
                        alt="{HOMEPAGE_FEATURED3_TITLE}" 
                        class="featured-image"
                        loading="lazy"
                        width="350"
                        height="350"
                        onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1584362917165-526a962b8c8c?w=350&h=350&fit=crop&q=80'; this.alt='Fishing Rod'"
                    >
                    <div class="featured-content">
                        <h3>{HOMEPAGE_FEATURED3_TITLE}</h3>
                        <p>{HOMEPAGE_FEATURED3_DESCRIPTION}</p>
                        <p class="featured-price">{HOMEPAGE_FEATURED3_PRICE}</p>
                    </div>
                </a>
            </div>
        </section>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
        
        <script>
            // Gallery navigation functionality
            document.addEventListener('DOMContentLoaded', function() {{
                const gallerySlides = document.getElementById('gallerySlides');
                const prevBtn = document.getElementById('prevBtn');
                const nextBtn = document.getElementById('nextBtn');
                const dots = document.querySelectorAll('.gallery-dot');
                const totalSlides = 4;
                let currentSlide = 0;
                let autoSlideInterval;
                
                // CONFIGURATION: Change these values to adjust timing
                const slideDuration = 7000; // 7 seconds per slide (7000 milliseconds)
                const transitionSpeed = 800; // 0.8 seconds for slide transition (800 milliseconds)
                
                // Set the transition duration on the slides element
                gallerySlides.style.transitionDuration = transitionSpeed + 'ms';
                
                // Initialize auto-slide
                startAutoSlide();
                
                // Function to update slide position
                function goToSlide(slideIndex) {{
                    // Ensure slide index is within bounds
                    if (slideIndex < 0) slideIndex = totalSlides - 1;
                    if (slideIndex >= totalSlides) slideIndex = 0;
                    
                    currentSlide = slideIndex;
                    const translateX = -currentSlide * 25; // 25% per slide
                    gallerySlides.style.transform = `translateX(${{translateX}}%)`;
                    
                    // Update active dot
                    dots.forEach((dot, index) => {{
                        dot.classList.toggle('active', index === currentSlide);
                    }});
                    
                    // Restart auto-slide timer
                    resetAutoSlide();
                }}
                
                // Next slide function (moves LEFT: image 1 → 2 → 3 → 4 → 1)
                function nextSlide() {{
                    currentSlide = (currentSlide + 1) % totalSlides;
                    goToSlide(currentSlide);
                }}
                
                // Previous slide function (moves RIGHT: image 1 ← 4 ← 3 ← 2 ← 1)
                function prevSlide() {{
                    currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
                    goToSlide(currentSlide);
                }}
                
                // Auto-slide functionality
                function startAutoSlide() {{
                    clearInterval(autoSlideInterval);
                    autoSlideInterval = setInterval(nextSlide, slideDuration);
                }}
                
                function resetAutoSlide() {{
                    clearInterval(autoSlideInterval);
                    startAutoSlide();
                }}
                
                // Event listeners for buttons
                prevBtn.addEventListener('click', function(e) {{
                    e.preventDefault();
                    e.stopPropagation();
                    prevSlide();
                }});
                
                nextBtn.addEventListener('click', function(e) {{
                    e.preventDefault();
                    e.stopPropagation();
                    nextSlide();
                }});
                
                // Event listeners for dots
                dots.forEach(dot => {{
                    dot.addEventListener('click', function(e) {{
                        e.preventDefault();
                        e.stopPropagation();
                        const slideIndex = parseInt(this.getAttribute('data-slide'));
                        goToSlide(slideIndex);
                    }});
                }});
                
                // Pause auto-slide on hover
                const galleryContainer = document.querySelector('.gallery-container');
                if (galleryContainer) {{
                    galleryContainer.addEventListener('mouseenter', () => {{
                        clearInterval(autoSlideInterval);
                    }});
                    
                    galleryContainer.addEventListener('mouseleave', () => {{
                        startAutoSlide();
                    }});
                }}
                
                // Keyboard navigation
                document.addEventListener('keydown', (e) => {{
                    if (e.key === 'ArrowLeft') {{
                        prevSlide();
                    }} else if (e.key === 'ArrowRight') {{
                        nextSlide();
                    }}
                }});
                
                // Pause gallery when not visible (for performance)
                if ('IntersectionObserver' in window) {{
                    const galleryObserver = new IntersectionObserver((entries) => {{
                        entries.forEach(entry => {{
                            if (entry.isIntersecting) {{
                                startAutoSlide();
                            }} else {{
                                clearInterval(autoSlideInterval);
                            }}
                        }});
                    }}, {{ threshold: 0.2 }});
                    
                    if (galleryContainer) {{
                        galleryObserver.observe(galleryContainer);
                    }}
                }}
                
                // Only preload absolutely critical images
                const criticalImages = [
                    "{COMPANY_LOGO_PATH}"
                ];
                
                criticalImages.forEach(url => {{
                    const img = new Image();
                    img.src = url;
                }});
                
                // Add performance optimization for featured items
                const featuredItems = document.querySelectorAll('.featured-item');
                featuredItems.forEach(item => {{
                    // Pre-cache hover state
                    item.addEventListener('mouseenter', function() {{
                        this.style.willChange = 'transform';
                    }});
                    
                    item.addEventListener('mouseleave', function() {{
                        // Reset will-change after animation
                        setTimeout(() => {{
                            this.style.willChange = 'auto';
                        }}, 250);
                    }});
                }});
            }});
            
            // Optimize for mobile touch devices
            document.addEventListener('touchstart', function() {{}}, {{passive: true}});
        </script>
    </body>
    </html>
    '''

@app.route('/catalog')
def catalog():
    """Rods catalog page"""
    column_order = [
        'Item Code', 'Brand', 'Model', 'Type', 'Reel type', 'Length', 
        'Joint Type', 'Power', 'Lure Weight', 'Action', 'Material', 
        'Guide', 'Reel Seat', 'Price', 'Discount', 'CR', 'GV', 
        'Warranty', 'After Discount', 'Final Price'
    ]
    
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500&family={font_family_url}:ital,wght@0,600;1,600&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{COMPANY_NAME} - Rods</title>
        <link href="{font_url}" rel="stylesheet">
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .catalog-header {{
                max-width: 1400px;
                margin: 40px auto;
                padding: 0 20px;
            }}
            .catalog-title {{
                text-align: center;
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 30px 0;
                font-weight: 600;
            }}
            .control-bar {{
                max-width: 1400px;
                margin: 0 auto 20px auto;
                padding: 0 20px;
                display: flex;
                gap: 10px;
                align-items: center;
            }}
            .search-input {{
                flex: 1;
                padding: 14px 20px;
                border: 2px solid #e1e7f0;
                border-radius: 8px;
                font-size: 16px;
                font-family: 'Inter', sans-serif;
                box-sizing: border-box;
            }}
            .search-input:focus {{
                outline: none;
                border-color: {STYLING_SECONDARY_COLOR};
                box-shadow: 0 0 0 3px rgba(31, 60, 136, 0.1);
            }}
            .filter-toggle-btn {{
                padding: 14px 24px;
                border: none;
                border-radius: 8px;
                background: {STYLING_SECONDARY_COLOR};
                color: white;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 8px;
                font-family: 'Inter', sans-serif;
                font-size: 15px;
            }}
            .clear-btn {{
                padding: 14px 24px;
                border: none;
                border-radius: 8px;
                background: #6c757d;
                color: white;
                font-weight: 600;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 8px;
                font-family: 'Inter', sans-serif;
                font-size: 15px;
            }}
            .filters-grid {{
                max-width: 1400px;
                margin: 0 auto 20px auto;
                padding: 0 20px;
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }}
            .filters-grid.hidden {{
                display: none;
            }}
            .filter-box {{
                background: white;
                border-radius: 8px;
                border: 1px solid #e1e7f0;
                overflow: hidden;
            }}
            .filter-box.collapsed .filter-options {{
                display: none;
            }}
            .filter-title {{
                padding: 15px 20px;
                background: #f8fafc;
                border-bottom: 1px solid #e1e7f0;
                cursor: pointer;
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-weight: 600;
                color: {STYLING_PRIMARY_COLOR};
            }}
            .filter-count {{
                color: #666;
                font-weight: normal;
                font-size: 14px;
            }}
            .filter-arrow {{
                transition: transform 0.3s;
            }}
            .filter-box.collapsed .filter-arrow {{
                transform: rotate(-90deg);
            }}
            .filter-options {{
                max-height: 200px;
                overflow-y: auto;
                padding: 15px;
            }}
            .filter-option {{
                display: block;
                padding: 8px 0;
                cursor: pointer;
            }}
            .filter-option input {{
                margin-right: 10px;
            }}
            .catalog-container {{
                max-width: 1400px;
                margin: 0 auto 60px auto;
                padding: 0 20px;
            }}
            .table-wrapper {{
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                background: white;
                overflow: hidden;
            }}
            .table-container {{
                overflow: auto;
                max-height: 600px;
            }}
            .product-table {{
                width: auto;
                min-width: 100%;
                border-collapse: collapse;
                font-size: 14px;
            }}
            .product-table thead {{
                position: sticky;
                top: 0;
                z-index: 10;
            }}
            .product-table th {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 16px 12px;
                text-align: left;
                font-weight: 600;
                white-space: nowrap;
                border-bottom: 2px solid {STYLING_SECONDARY_COLOR};
                position: sticky;
                top: 0;
            }}
            .product-table th:nth-child(1) {{ width: 100px; }}
            .product-table th:nth-child(2) {{ width: 120px; }}
            .product-table th:nth-child(3) {{ width: 200px; }}
            .product-table th:nth-child(4) {{ width: 100px; }}
            .product-table th:nth-child(5) {{ width: 100px; }}
            .product-table th:nth-child(6) {{ width: 100px; }}
            .product-table th:nth-child(7) {{ width: 100px; }}
            .product-table th:nth-child(8) {{ width: 100px; }}
            .product-table th:nth-child(9) {{ width: 120px; }}
            .product-table th:nth-child(10) {{ width: 100px; }}
            .product-table th:nth-child(11) {{ width: 120px; }}
            .product-table th:nth-child(12) {{ width: 100px; }}
            .product-table th:nth-child(13) {{ width: 120px; }}
            .product-table th:nth-child(14) {{ width: 100px; }}
            .product-table th:nth-child(15) {{ width: 100px; }}
            .product-table th:nth-child(16) {{ width: 80px; }}
            .product-table th:nth-child(17) {{ width: 80px; }}
            .product-table th:nth-child(18) {{ width: 100px; }}
            .product-table th:nth-child(19) {{ width: 120px; }}
            .product-table th:nth-child(20) {{ width: 120px; }}
            .product-table td {{
                padding: 12px 12px;
                border-bottom: 1px solid #e9ecef;
                color: {STYLING_TEXT_COLOR};
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }}
            .product-table td:nth-child(1) {{ width: 100px; }}
            .product-table td:nth-child(2) {{ width: 120px; }}
            .product-table td:nth-child(3) {{ width: 200px; }}
            .product-table td:nth-child(4) {{ width: 100px; }}
            .product-table td:nth-child(5) {{ width: 100px; }}
            .product-table td:nth-child(6) {{ width: 100px; }}
            .product-table td:nth-child(7) {{ width: 100px; }}
            .product-table td:nth-child(8) {{ width: 100px; }}
            .product-table td:nth-child(9) {{ width: 120px; }}
            .product-table td:nth-child(10) {{ width: 100px; }}
            .product-table td:nth-child(11) {{ width: 120px; }}
            .product-table td:nth-child(12) {{ width: 100px; }}
            .product-table td:nth-child(13) {{ width: 120px; }}
            .product-table td:nth-child(14) {{ width: 100px; }}
            .product-table td:nth-child(15) {{ width: 100px; }}
            .product-table td:nth-child(16) {{ width: 80px; }}
            .product-table td:nth-child(17) {{ width: 80px; }}
            .product-table td:nth-child(18) {{ width: 100px; }}
            .product-table td:nth-child(19) {{ width: 120px; }}
            .product-table td:nth-child(20) {{ width: 120px; }}
            .product-table tr:hover {{
                background-color: #f8f9fa;
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
                .catalog-title {{
                    font-size: 28px;
                }}
                .control-bar {{
                    flex-direction: column;
                    gap: 10px;
                }}
                .search-input, .filter-toggle-btn, .clear-btn {{
                    width: 100%;
                }}
                .filters-grid {{
                    grid-template-columns: 1fr;
                    gap: 15px;
                }}
                .table-container {{
                    max-height: 500px;
                }}
                .product-table th, .product-table td {{
                    font-size: 12px;
                    padding: 10px 8px;
                }}
                .product-table th:nth-child(1), .product-table td:nth-child(1) {{ width: 80px; }}
                .product-table th:nth-child(2), .product-table td:nth-child(2) {{ width: 90px; }}
                .product-table th:nth-child(3), .product-table td:nth-child(3) {{ width: 150px; }}
                .product-table th:nth-child(4), .product-table td:nth-child(4) {{ width: 70px; }}
                .product-table th:nth-child(5), .product-table td:nth-child(5) {{ width: 80px; }}
                .product-table th:nth-child(6), .product-table td:nth-child(6) {{ width: 70px; }}
                .product-table th:nth-child(7), .product-table td:nth-child(7) {{ width: 80px; }}
                .product-table th:nth-child(8), .product-table td:nth-child(8) {{ width: 80px; }}
                .product-table th:nth-child(9), .product-table td:nth-child(9) {{ width: 90px; }}
                .product-table th:nth-child(10), .product-table td:nth-child(10) {{ width: 80px; }}
                .product-table th:nth-child(11), .product-table td:nth-child(11) {{ width: 90px; }}
                .product-table th:nth-child(12), .product-table td:nth-child(12) {{ width: 70px; }}
                .product-table th:nth-child(13), .product-table td:nth-child(13) {{ width: 90px; }}
                .product-table th:nth-child(14), .product-table td:nth-child(14) {{ width: 80px; }}
                .product-table th:nth-child(15), .product-table td:nth-child(15) {{ width: 80px; }}
                .product-table th:nth-child(16), .product-table td:nth-child(16) {{ width: 60px; }}
                .product-table th:nth-child(17), .product-table td:nth-child(17) {{ width: 60px; }}
                .product-table th:nth-child(18), .product-table td:nth-child(18) {{ width: 80px; }}
                .product-table th:nth-child(19), .product-table td:nth-child(19) {{ width: 100px; }}
                .product-table th:nth-child(20), .product-table td:nth-child(20) {{ width: 100px; }}
            }}
        </style>
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item active">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <section class="catalog-header">
            <h2 class="catalog-title">Rods</h2>
        </section>

        <div class="control-bar">
            <input type="text" class="search-input" id="searchInput" placeholder="🔍 Search rods by brand, model, type, etc..." oninput="filterTable()">
            <button class="filter-toggle-btn" onclick="toggleFilters()"><span>🔍</span> Filters</button>
            <button class="clear-btn" onclick="clearAllFilters()"><span>✕</span> Clear</button>
        </div>

        <div id="filtersGrid" class="filters-grid hidden">
            <div id="filtersCol1"></div>
            <div id="filtersCol2"></div>
        </div>

        <div class="catalog-container">
            <div class="table-wrapper">
                <div class="table-container">
                    <table class="product-table">
                        <thead>
                            <tr id="tableHeader">
                                {''.join(f'<th>{column}</th>' for column in column_order)}
                            </tr>
                        </thead>
                        <tbody id="tableBody"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>

        <script>
            const API_URL = "/api/rods";
            let allProducts = [];
            let filteredProducts = [];
            let filtersVisible = false;
            let activeFilters = {{}};
            
            document.addEventListener('DOMContentLoaded', loadCatalog);
            
            async function loadCatalog() {{
                try {{
                    const response = await fetch(API_URL);
                    const result = await response.json();
                    
                    if (result.status === 'error') {{
                        console.error("Error loading rods:", result.message);
                        return;
                    }}
                    
                    allProducts = result.data || [];
                    
                    if (allProducts.length === 0) {{
                        document.getElementById('tableBody').innerHTML = '<tr><td colspan="20" style="text-align: center; padding: 50px;">No rods found</td></tr>';
                        return;
                    }}
                    
                    const nonEmptyProducts = allProducts.filter(product => !isRowEmpty(product));
                    
                    if (nonEmptyProducts.length === 0) {{
                        document.getElementById('tableBody').innerHTML = '<tr><td colspan="20" style="text-align: center; padding: 50px;">No valid rods found</td></tr>';
                        return;
                    }}
                    
                    allProducts = nonEmptyProducts;
                    filteredProducts = [...allProducts];
                    
                    populateTable();
                    populateFilters();
                    
                }} catch (error) {{
                    console.error('Error:', error);
                }}
            }}
            
            function isRowEmpty(rod) {{
                const values = Object.values(rod);
                return values.every(v => {{
                    if (v === null || v === undefined) return true;
                    const strValue = String(v).trim().toLowerCase();
                    if (strValue === '') return true;
                    if (strValue === '0') return true;
                    if (strValue === 'null') return true;
                    if (strValue === 'nan') return true;
                    if (strValue === '-') return true;
                    if (strValue === 'n/a') return true;
                    return false;
                }});
            }}
            
            function toggleFilters() {{
                filtersVisible = !filtersVisible;
                const grid = document.getElementById('filtersGrid');
                const button = document.querySelector('.filter-toggle-btn');
                grid.classList.toggle('hidden');
                button.innerHTML = filtersVisible ? '<span>▲</span> Hide Filters' : '<span>🔍</span> Filters';
            }}
            
            function populateFilters() {{
                const filterColumns = ['Brand', 'Type', 'Power', 'Action', 'Length', 'Material', 'Reel type'];
                filterColumns.forEach((column, index) => {{
                    const values = new Set();
                    allProducts.forEach(product => {{
                        const value = product[column];
                        if (value !== undefined && value !== null && String(value).trim() !== '') {{
                            values.add(String(value).trim());
                        }}
                    }});
                    if (values.size === 0) return;
                    const sortedValues = [...values].sort();
                    const filterBox = document.createElement('div');
                    filterBox.className = 'filter-box collapsed';
                    filterBox.innerHTML = `
                        <div class="filter-title" onclick="toggleFilterBox(this)">
                            <span>${{column}} <span class="filter-count">(${{values.size}})</span></span>
                            <span class="filter-arrow">▼</span>
                        </div>
                        <div class="filter-options">
                            ${{sortedValues.map(value => `
                                <label class="filter-option">
                                    <input type="checkbox" data-column="${{column}}" value="${{escapeHtml(value).replace(/"/g, '&quot;')}}" onchange="updateActiveFilters()">
                                    <span>${{escapeHtml(value)}}</span>
                                </label>
                            `).join('')}}
                        </div>
                    `;
                    if (index % 2 === 0) {{
                        document.getElementById('filtersCol1').appendChild(filterBox);
                    }} else {{
                        document.getElementById('filtersCol2').appendChild(filterBox);
                    }}
                }});
            }}
            
            function toggleFilterBox(element) {{
                element.parentElement.classList.toggle('collapsed');
            }}
            
            function updateActiveFilters() {{
                activeFilters = {{}};
                document.querySelectorAll('.filter-options input:checked').forEach(checkbox => {{
                    const column = checkbox.getAttribute('data-column');
                    const value = checkbox.value;
                    if (!activeFilters[column]) {{
                        activeFilters[column] = [];
                    }}
                    if (!activeFilters[column].includes(value)) {{
                        activeFilters[column].push(value);
                    }}
                }});
                filterTable();
            }}
            
            function clearAllFilters() {{
                document.querySelectorAll('.filter-options input[type="checkbox"]').forEach(cb => {{
                    cb.checked = false;
                }});
                document.getElementById('searchInput').value = '';
                activeFilters = {{}};
                filteredProducts = [...allProducts];
                populateTable();
                const clearBtn = document.querySelector('.clear-btn');
                const originalHTML = clearBtn.innerHTML;
                clearBtn.innerHTML = '<span>✓</span> Cleared!';
                clearBtn.style.background = '#28a745';
                setTimeout(() => {{
                    clearBtn.innerHTML = originalHTML;
                    clearBtn.style.background = '';
                }}, 1500);
            }}
            
            function filterTable() {{
                const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
                filteredProducts = allProducts.filter(product => {{
                    if (searchTerm) {{
                        const searchMatch = Object.values(product).some(value => {{
                            if (value === undefined || value === null) return false;
                            return String(value).toLowerCase().includes(searchTerm);
                        }});
                        if (!searchMatch) return false;
                    }}
                    for (const [column, selectedValues] of Object.entries(activeFilters)) {{
                        if (selectedValues.length > 0) {{
                            const cellValue = String(product[column] || '').toLowerCase().trim();
                            const matches = selectedValues.some(v => cellValue === v.toLowerCase().trim());
                            if (!matches) return false;
                        }}
                    }}
                    return true;
                }});
                populateTable();
            }}
            
            function populateTable() {{
                const tableBody = document.getElementById('tableBody');
                const columnOrder = [
                    'Item Code', 'Brand', 'Model', 'Type', 'Reel type', 'Length', 
                    'Joint Type', 'Power', 'Lure Weight', 'Action', 'Material', 
                    'Guide', 'Reel Seat', 'Price', 'Discount', 'CR', 'GV', 
                    'Warranty', 'After Discount', 'Final Price'
                ];
                if (filteredProducts.length === 0) {{
                    tableBody.innerHTML = `
                        <tr>
                            <td colspan="20" style="text-align: center; padding: 50px; color: #666;">
                                No rods match your search
                            </td>
                        </tr>
                    `;
                    return;
                }}
                tableBody.innerHTML = filteredProducts.map(product => {{
                    return `<tr>
                        ${{columnOrder.map(column => {{
                            let value = product[column] || '';
                            return `<td title="${{escapeHtml(String(value).trim())}}">${{escapeHtml(String(value).trim())}}</td>`;
                        }}).join('')}}
                    </tr>`;
                }}).join('');
            }}
            
            function escapeHtml(text) {{
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }}
        </script>
    </body>
    </html>
    '''

@app.route('/rods')
def rods():
    """Alias for catalog"""
    return catalog()

@app.route('/reels')
def reels():
    """Reels page"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - Reels</title>
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .content {{
                max-width: 1200px;
                margin: 60px auto;
                padding: 0 20px;
                text-align: center;
            }}
            .content h1 {{
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 20px 0;
                font-weight: 600;
            }}
            .content p {{
                color: #666;
                font-size: 18px;
                line-height: 1.6;
                max-width: 600px;
                margin: 0 auto 40px auto;
            }}
            .coming-soon {{
                background: white;
                padding: 60px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                border: 2px dashed {STYLING_SECONDARY_COLOR};
            }}
            .coming-soon h2 {{
                color: {STYLING_PRIMARY_COLOR};
                margin: 0 0 20px 0;
                font-size: 28px;
            }}
            .coming-soon p {{
                color: #555;
                margin: 0 0 30px 0;
            }}
            .icon {{
                font-size: 64px;
                margin: 20px 0;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .content h1 {{
                    font-size: 28px;
                }}
                .coming-soon {{
                    padding: 30px 20px;
                }}
                .icon {{
                    font-size: 48px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item active">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <div class="content">
            <h1>Fishing Reels</h1>
            <p>Our premium collection of fishing reels is coming soon!</p>
            
            <div class="coming-soon">
                <div class="icon">🌀</div>
                <h2>Premium Reels Coming Soon</h2>
                <p>We're currently curating an exceptional selection of spinning, baitcasting, and conventional reels from top brands worldwide.</p>
                <p>Check back soon for our comprehensive reel catalog featuring the latest technology and innovations in fishing reels.</p>
            </div>
        </div>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
    </body>
    </html>
    '''

@app.route('/accessories')
def accessories():
    """Accessories page"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - Accessories</title>
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .content {{
                max-width: 1200px;
                margin: 60px auto;
                padding: 0 20px;
                text-align: center;
            }}
            .content h1 {{
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 20px 0;
                font-weight: 600;
            }}
            .content p {{
                color: #666;
                font-size: 18px;
                line-height: 1.6;
                max-width: 600px;
                margin: 0 auto 40px auto;
            }}
            .coming-soon {{
                background: white;
                padding: 60px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                border: 2px dashed {STYLING_SECONDARY_COLOR};
            }}
            .coming-soon h2 {{
                color: {STYLING_PRIMARY_COLOR};
                margin: 0 0 20px 0;
                font-size: 28px;
            }}
            .coming-soon p {{
                color: #555;
                margin: 0 0 30px 0;
            }}
            .icon {{
                font-size: 64px;
                margin: 20px 0;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .content h1 {{
                    font-size: 28px;
                }}
                .coming-soon {{
                    padding: 30px 20px;
                }}
                .icon {{
                    font-size: 48px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item active">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <div class="content">
            <h1>Fishing Accessories</h1>
            <p>Our premium collection of fishing accessories is coming soon!</p>
            
            <div class="coming-soon">
                <div class="icon">🎯</div>
                <h2>Fishing Accessories Coming Soon</h2>
                <p>We're currently assembling a comprehensive range of fishing accessories including lines, lures, hooks, tackle boxes, and more.</p>
                <p>Check back soon for our complete accessories catalog featuring everything you need for a successful fishing trip.</p>
            </div>
        </div>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
    </body>
    </html>
    '''
@app.route('/products')
def products_list():
    """List all products"""
    try:
        # Load products data
        products_json = Path("database/products.json")
        if products_json.exists():
            with open(products_json, 'r') as f:
                products_data = json.load(f)
            products = products_data.get("products", [])
        else:
            products = []
        
        # Create config object for template
        class Config:
            SITE_NAME = COMPANY_NAME
            COMPANY_LOGO_PATH = COMPANY_LOGO_PATH
            COMPANY_FONT_FAMILY = COMPANY_FONT_FAMILY
            COMPANY_ESTABLISHED_YEAR = COMPANY_ESTABLISHED_YEAR
            STYLING_PRIMARY_COLOR = STYLING_PRIMARY_COLOR
            STYLING_SECONDARY_COLOR = STYLING_SECONDARY_COLOR
            STYLING_ACCENT_COLOR = STYLING_ACCENT_COLOR
            STYLING_BACKGROUND_COLOR = STYLING_BACKGROUND_COLOR
            STYLING_TEXT_COLOR = STYLING_TEXT_COLOR
            STYLING_NAV_HEIGHT = STYLING_NAV_HEIGHT
            STYLING_FONT_SIZE_NAV = STYLING_FONT_SIZE_NAV
            STYLING_FONT_SIZE_TITLE = STYLING_FONT_SIZE_TITLE
            STYLING_FONT_SIZE_BODY = STYLING_FONT_SIZE_BODY
        
        config_obj = Config()
        
        return render_template('products_list.html', 
                             products=products,
                             config=config_obj)  # <-- FIXED
    except Exception as e:
        return f"Error loading products: {str(e)}", 500

@app.route('/product/<product_id>')
def product_detail(product_id):
    """Individual product page"""
    try:
        # Load products data
        products_json = Path("database/products.json")
        if not products_json.exists():
            return "Products data not found", 404
        
        with open(products_json, 'r') as f:
            products_data = json.load(f)
        
        # Find the product
        product = None
        for p in products_data.get("products", []):
            if p.get("id") == product_id or p.get("sku") == product_id:
                product = p
                break
        
        if not product:
            return "Product not found", 404
        
        # Get related products (same brand)
        related = []
        for p in products_data.get("products", []):
            if (p.get("id") != product_id and 
                p.get("brand") == product.get("brand")):
                related.append(p)
            if len(related) >= 4:
                break
        
        # Create config object for template
        class Config:
            SITE_NAME = COMPANY_NAME
            COMPANY_LOGO_PATH = COMPANY_LOGO_PATH
            COMPANY_FONT_FAMILY = COMPANY_FONT_FAMILY
            COMPANY_ESTABLISHED_YEAR = COMPANY_ESTABLISHED_YEAR
            STYLING_PRIMARY_COLOR = STYLING_PRIMARY_COLOR
            STYLING_SECONDARY_COLOR = STYLING_SECONDARY_COLOR
            STYLING_ACCENT_COLOR = STYLING_ACCENT_COLOR
            STYLING_BACKGROUND_COLOR = STYLING_BACKGROUND_COLOR
            STYLING_TEXT_COLOR = STYLING_TEXT_COLOR
            STYLING_NAV_HEIGHT = STYLING_NAV_HEIGHT
            STYLING_FONT_SIZE_NAV = STYLING_FONT_SIZE_NAV
            STYLING_FONT_SIZE_TITLE = STYLING_FONT_SIZE_TITLE
            STYLING_FONT_SIZE_BODY = STYLING_FONT_SIZE_BODY
        
        config_obj = Config()
        
        return render_template('product_detail.html',
                             product=product,
                             related_products=related,
                             config=config_obj)
        
    except Exception as e:
        return f"Error loading product: {str(e)}", 500

# Add this route to link from your catalog table
@app.route('/rod/<item_code>')
def rod_detail(item_code):
    """Alias for product detail page for rods"""
    return product_detail(item_code)

@app.route('/apparel')
def apparel():
    """Apparel page"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - Apparel</title>
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .content {{
                max-width: 1200px;
                margin: 60px auto;
                padding: 0 20px;
                text-align: center;
            }}
            .content h1 {{
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                margin: 0 0 20px 0;
                font-weight: 600;
            }}
            .content p {{
                color: #666;
                font-size: 18px;
                line-height: 1.6;
                max-width: 600px;
                margin: 0 auto 40px auto;
            }}
            .coming-soon {{
                background: white;
                padding: 60px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                border: 2px dashed {STYLING_SECONDARY_COLOR};
            }}
            .coming-soon h2 {{
                color: {STYLING_PRIMARY_COLOR};
                margin: 0 0 20px 0;
                font-size: 28px;
            }}
            .coming-soon p {{
                color: #555;
                margin: 0 0 30px 0;
            }}
            .icon {{
                font-size: 64px;
                margin: 20px 0;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .content h1 {{
                    font-size: 28px;
                }}
                .coming-soon {{
                    padding: 30px 20px;
                }}
                .icon {{
                    font-size: 48px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item active">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <div class="content">
            <h1>Fishing Apparel</h1>
            <p>Our premium collection of fishing apparel is coming soon!</p>
            
            <div class="coming-soon">
                <div class="icon">👕</div>
                <h2>Fishing Apparel Coming Soon</h2>
                <p>We're currently selecting the finest fishing apparel including shirts, hats, waterproof jackets, and protective gear.</p>
                <p>Check back soon for our complete apparel catalog featuring comfortable and functional clothing for every fishing adventure.</p>
            </div>
        </div>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
    </body>
    </html>
    '''

@app.route('/contact')
def contact():
    """Contact page"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - Contact</title>
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .content {{
                max-width: 1200px;
                margin: 60px auto;
                padding: 0 20px;
            }}
            .content h1 {{
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                text-align: center;
                margin: 0 0 40px 0;
                font-weight: 600;
            }}
            .contact-info {{
                background: white;
                padding: 50px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 40px;
            }}
            .contact-item {{
                padding: 25px;
                background: #f8fafc;
                border-radius: 10px;
                border-left: 4px solid {STYLING_SECONDARY_COLOR};
            }}
            .contact-item h3 {{
                color: {STYLING_PRIMARY_COLOR};
                margin: 0 0 15px 0;
                font-size: 22px;
                font-weight: 600;
            }}
            .contact-item p {{
                margin: 0;
                color: #555;
                line-height: 1.7;
                font-size: 16px;
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .content h1 {{
                    font-size: 28px;
                }}
                .contact-info {{
                    padding: 20px;
                    grid-template-columns: 1fr;
                    gap: 20px;
                }}
                .contact-item {{
                    padding: 20px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link active">Contact</a></li>
                    <li><a href="/about" class="nav-link">About</a></li>
                </ul>
            </div>
        </nav>
        
        <div class="content">
            <h1>Contact Us</h1>
            <div class="contact-info">
                <div class="contact-item">
                    <h3>Store Address</h3>
                    <p>{CONTACT_ADDRESS_LINE1}<br>{CONTACT_ADDRESS_LINE2}<br>{CONTACT_ADDRESS_LINE3}</p>
                </div>
                <div class="contact-item">
                    <h3>Phone Number</h3>
                    <p>{CONTACT_PHONE}</p>
                </div>
                <div class="contact-item">
                    <h3>Email Address</h3>
                    <p>{CONTACT_EMAIL}</p>
                </div>
                <div class="contact-item">
                    <h3>Business Hours</h3>
                    <p>Monday - Friday: {CONTACT_HOURS_MON_FRI}<br>Saturday: {CONTACT_HOURS_SAT}<br>Sunday: {CONTACT_HOURS_SUN}</p>
                </div>
            </div>
        </div>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
    </body>
    </html>
    '''

@app.route('/about')
def about():
    """About page"""
    font_family_url = COMPANY_FONT_FAMILY.replace(' ', '+')
    font_url = f"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family={font_family_url}:ital,wght@0,600;0,700;1,600;1,700&display=swap"
    
    return f'''
    <!DOCTYPE html>
    <html>
    <head>
        <title>{COMPANY_NAME} - About</title>
        <style>
            body {{
                font-family: 'Inter', Arial, sans-serif;
                margin: 0;
                padding: 0;
                background: {STYLING_BACKGROUND_COLOR};
            }}
            .main-nav {{
                background: {STYLING_PRIMARY_COLOR};
                padding: 0 20px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                height: {STYLING_NAV_HEIGHT};
                position: sticky;
                top: 0;
                z-index: 1000;
            }}
            .nav-container {{
                max-width: 1400px;
                margin: 0 auto;
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0;
                height: 100%;
            }}
            .logo-area {{
                display: flex;
                align-items: center;
                gap: 20px;
                height: 100%;
            }}
            .logo-img {{
                height: 100px;
                width: auto;
                object-fit: contain;
                filter: drop-shadow(0 2px 4px rgba(0,0,0,0.2));
                border-radius: 5px;
            }}
            .brand-name {{
                color: white;
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_NAV};
                font-weight: {COMPANY_FONT_WEIGHT};
                font-style: {COMPANY_FONT_STYLE};
                text-decoration: none;
                letter-spacing: 1px;
                text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
            }}
            .nav-menu {{
                display: flex;
                list-style: none;
                margin: 0;
                padding: 0;
                gap: 10px;
                align-items: center;
            }}
            .nav-link {{
                color: white;
                text-decoration: none;
                padding: 20px 25px;
                display: block;
                font-size: {STYLING_FONT_SIZE_BODY};
                transition: all 0.3s;
                border-radius: 6px;
                font-weight: 500;
            }}
            .nav-link:hover {{
                background: rgba(255,255,255,0.15);
            }}
            .nav-link.active {{
                background: {STYLING_SECONDARY_COLOR};
                font-weight: 600;
            }}
            .dropdown {{
                position: relative;
            }}
            .dropdown-menu {{
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                background: white;
                min-width: 200px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.15);
                border-radius: 8px;
                padding: 10px 0;
                z-index: 1000;
            }}
            .dropdown:hover .dropdown-menu {{
                display: block;
            }}
            .dropdown-item {{
                display: block;
                padding: 12px 20px;
                color: {STYLING_PRIMARY_COLOR};
                text-decoration: none;
                font-size: 16px;
                transition: background 0.3s;
            }}
            .dropdown-item:hover {{
                background: #f8fafc;
                color: {STYLING_SECONDARY_COLOR};
            }}
            .dropdown-item.active {{
                background: {STYLING_SECONDARY_COLOR};
                color: white;
            }}
            .content {{
                max-width: 1000px;
                margin: 60px auto;
                padding: 0 20px;
            }}
            .content h1 {{
                color: {STYLING_PRIMARY_COLOR};
                font-family: '{COMPANY_FONT_FAMILY}', serif;
                font-size: {STYLING_FONT_SIZE_TITLE};
                text-align: center;
                margin: 0 0 40px 0;
                font-weight: 600;
            }}
            .about-section {{
                background: white;
                padding: 50px;
                border-radius: 15px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.1);
            }}
            .about-section p {{
                line-height: 1.8;
                color: #555;
                font-size: 18px;
                margin: 0 0 25px 0;
            }}
            .about-section p:last-child {{
                margin-bottom: 0;
            }}
            .highlight {{
                color: {STYLING_PRIMARY_COLOR};
                font-weight: 600;
                font-size: 20px;
            }}
            .mission-statement {{
                background: {STYLING_SECONDARY_COLOR}15;
                border-left: 4px solid {STYLING_SECONDARY_COLOR};
                padding: 25px;
                margin: 30px 0;
                border-radius: 0 10px 10px 0;
            }}
            .mission-statement p {{
                color: {STYLING_PRIMARY_COLOR};
                font-style: italic;
                font-weight: 500;
                margin: 0;
            }}
            .footer-disclaimer {{
                background: {STYLING_PRIMARY_COLOR};
                color: white;
                padding: 40px 20px;
                text-align: center;
                margin-top: 80px;
                font-size: {STYLING_FONT_SIZE_BODY};
                border-top: 3px solid {STYLING_ACCENT_COLOR};
            }}
            .footer-disclaimer p {{
                margin: 10px 0;
                opacity: 0.95;
            }}
            .established {{
                font-style: italic;
                color: {STYLING_ACCENT_COLOR};
                font-weight: 600;
                font-size: 18px;
                margin-top: 15px;
            }}
            @media (max-width: 768px) {{
                .main-nav {{
                    height: auto;
                    min-height: 100px;
                }}
                .brand-name {{
                    font-size: 32px;
                }}
                .logo-img {{
                    height: 70px;
                }}
                .nav-link {{
                    padding: 18px 20px;
                    font-size: 16px;
                }}
                .content h1 {{
                    font-size: 28px;
                }}
                .about-section {{
                    padding: 30px 20px;
                }}
                .about-section p {{
                    font-size: 16px;
                }}
                .mission-statement {{
                    padding: 20px;
                }}
                .dropdown-menu {{
                    position: static;
                    box-shadow: none;
                    background: {STYLING_PRIMARY_COLOR};
                    border-radius: 0;
                    padding: 0;
                }}
                .dropdown-item {{
                    color: white;
                    padding: 15px 30px;
                    border-top: 1px solid rgba(255,255,255,0.1);
                }}
                .dropdown-item:hover {{
                    background: rgba(255,255,255,0.1);
                    color: white;
                }}
            }}
        </style>
        <link href="{font_url}" rel="stylesheet">
    </head>
    <body>
        <nav class="main-nav">
            <div class="nav-container">
                <div class="logo-area">
                    <img src="{COMPANY_LOGO_PATH}" alt="{COMPANY_NAME}" class="logo-img" onerror="this.style.display='none'">
                    <a href="/" class="brand-name">{COMPANY_NAME}</a>
                </div>
                <ul class="nav-menu">
                    <li><a href="/" class="nav-link">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="nav-link">Products ▾</a>
                        <div class="dropdown-menu">
                            <a href="/catalog" class="dropdown-item">Rods</a>
                            <a href="/reels" class="dropdown-item">Reels</a>
                            <a href="/accessories" class="dropdown-item">Accessories</a>
                            <a href="/apparel" class="dropdown-item">Apparel</a>
                        </div>
                    </li>
                    <li><a href="/contact" class="nav-link">Contact</a></li>
                    <li><a href="/about" class="nav-link active">About</a></li>
                </ul>
            </div>
        </nav>
        
        <div class="content">
            <h1>About {COMPANY_NAME}</h1>
            <div class="about-section">
                <p><span class="highlight">{COMPANY_NAME}</span> was established in {COMPANY_ESTABLISHED_YEAR} with a simple mission: to provide anglers with the highest quality fishing equipment available.</p>
                
                <p>We're dedicated to sourcing the finest rods, reels, and fishing accessories from renowned brands worldwide. Our expertise comes from years of hands-on experience - we're not just sellers, we're passionate anglers who understand the needs of both recreational and professional fishermen.</p>
                
                <div class="mission-statement">
                    <p>"Our commitment extends beyond just selling products. We believe in building lasting relationships with our customers by offering expert advice, reliable service, and products we truly believe in."</p>
                </div>
                
                <p>Every item in our catalog is carefully selected based on performance, durability, and value. We test products in real fishing conditions to ensure they meet our high standards before recommending them to our customers.</p>
                
                <p>At <span class="highlight">{COMPANY_NAME}</span>, we're proud to be part of the fishing community and look forward to serving generations of anglers to come. Whether you're just starting out or are a seasoned professional, we're here to help you make the most of every fishing adventure.</p>
            </div>
        </div>
        
        <footer class="footer-disclaimer">
            <p>© 1987 {COMPANY_NAME}. All specifications are subject to availability.</p>
            <p class="established">Established {COMPANY_ESTABLISHED_YEAR}</p>
        </footer>
    </body>
    </html>
    '''

@app.route('/api/rods')
def api_rods():
    """API endpoint for rods data"""
    data = load_rods_data()
    
    if isinstance(data, dict) and "error" in data:
        return jsonify({
            "status": "error",
            "message": data["error"],
            "timestamp": time.time(),
            "cached": _data_cache is not None
        }), 500
    else:
        ordered_data = []
        for rod in data:
            ordered_rod = {}
            for column in [
                'Item Code', 'Brand', 'Model', 'Type', 'Reel type', 'Length', 
                'Joint Type', 'Power', 'Lure Weight', 'Action', 'Material', 
                'Guide', 'Reel Seat', 'Price', 'Discount', 'CR', 'GV', 
                'Warranty', 'After Discount', 'Final Price'
            ]:
                ordered_rod[column] = rod.get(column, '')
            ordered_data.append(ordered_rod)
        
        return jsonify({
            "status": "success",
            "count": len(ordered_data),
            "timestamp": time.time(),
            "cached": time.time() - _cache_time < CACHE_DURATION if _cache_time else False,
            "columns": [
                'Item Code', 'Brand', 'Model', 'Type', 'Reel type', 'Length', 
                'Joint Type', 'Power', 'Lure Weight', 'Action', 'Material', 
                'Guide', 'Reel Seat', 'Price', 'Discount', 'CR', 'GV', 
                'Warranty', 'After Discount', 'Final Price'
            ],
            "data": ordered_data
        })

@app.route('/health')
def health():
    """Health check"""
    data = load_rods_data()
    
    if isinstance(data, dict) and "error" in data:
        return jsonify({
            "status": "unhealthy",
            "error": data["error"],
            "timestamp": time.time()
        }), 500
    else:
        return jsonify({
            "status": "healthy",
            "rod_count": len(data),
            "cache_age": time.time() - _cache_time if _cache_time else None,
            "timestamp": time.time()
        })

# ============================================
# MAIN
# ============================================

if __name__ == '__main__':
    # Create necessary folders
    Path("static/images/gallery").mkdir(parents=True, exist_ok=True)
    Path("static/images/category").mkdir(parents=True, exist_ok=True)
    Path("static/images/featured").mkdir(parents=True, exist_ok=True)
    
    port = 5000
    app.run(debug=True, port=port, host='0.0.0.0')