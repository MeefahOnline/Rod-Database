# data_loader.py - Load and process product data

import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Any
from functools import lru_cache

from config import config, PRODUCTS_JSON, RODS_JSON, IMAGE_MAPPING_JSON

class ProductDataLoader:
    """Load and manage product data with caching"""
    
    def __init__(self):
        self._data_cache = None
        self._cache_time = 0
        self._cache_duration = config.CACHE_TIMEOUT
        
    def load_products(self) -> Dict[str, Any]:
        """Load products from JSON file with caching"""
        
        # Return cached data if still valid
        if (self._data_cache and 
            time.time() - self._cache_time < self._cache_duration):
            return self._data_cache
        
        try:
            # Try to load from processed products.json first
            if PRODUCTS_JSON.exists():
                with open(PRODUCTS_JSON, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            # Fall back to your existing rods.json
            elif RODS_JSON.exists():
                with open(RODS_JSON, 'r', encoding='utf-8') as f:
                    rods_data = json.load(f)
                data = self._process_rods_data(rods_data)
            else:
                data = {"products": [], "categories": {}, "brands": {}}
            
            # Cache the data
            self._data_cache = data
            self._cache_time = time.time()
            
            return data
            
        except Exception as e:
            print(f"Error loading product data: {e}")
            return {"products": [], "categories": {}, "brands": {}}
    
    def _process_rods_data(self, rods_data: List[Dict]) -> Dict[str, Any]:
        """Convert your existing rods.json to the new format"""
        products = []
        categories = set()
        brands = set()
        
        for rod in rods_data:
            # Create standardized product structure
            product = {
                "id": rod.get("Item Code", "").strip(),
                "sku": rod.get("Item Code", "").strip(),
                "title": f"{rod.get('Brand', '')} {rod.get('Model', '')}".strip(),
                "brand": rod.get("Brand", "").strip(),
                "model": rod.get("Model", "").strip(),
                "category": "Rods",
                "subcategory": rod.get("Type", "").strip(),
                "description": self._generate_description(rod),
                "price": self._parse_price(rod.get("Price", "0")),
                "discount": self._parse_discount(rod.get("Discount", "0")),
                "final_price": self._parse_price(rod.get("Final Price", rod.get("Price", "0"))),
                "specifications": self._extract_specifications(rod),
                "images": self._get_product_images(rod.get("Item Code", "").strip()),
                "in_stock": True,
                "created_at": time.time(),
                "updated_at": time.time()
            }
            
            products.append(product)
            categories.add("Rods")
            if product["brand"]:
                brands.add(product["brand"])
        
        return {
            "products": products,
            "categories": sorted(list(categories)),
            "brands": sorted(list(brands))
        }
    
    def _generate_description(self, rod: Dict) -> str:
        """Generate a product description from rod data"""
        specs = []
        if rod.get("Length"):
            specs.append(f"Length: {rod['Length']}")
        if rod.get("Power"):
            specs.append(f"Power: {rod['Power']}")
        if rod.get("Action"):
            specs.append(f"Action: {rod['Action']}")
        
        desc = f"Premium fishing rod designed for optimal performance. "
        if specs:
            desc += f"Features include: {', '.join(specs)}. "
        desc += "Ideal for both amateur and professional anglers."
        
        return desc
    
    def _parse_price(self, price_str: str) -> float:
        """Convert price string to float"""
        try:
            # Remove currency symbols and commas
            cleaned = str(price_str).replace('RM', '').replace('$', '').replace(',', '').strip()
            return float(cleaned) if cleaned else 0.0
        except:
            return 0.0
    
    def _parse_discount(self, discount_str: str) -> float:
        """Convert discount string to percentage float"""
        try:
            cleaned = str(discount_str).replace('%', '').strip()
            return float(cleaned) / 100 if cleaned else 0.0  # Convert to decimal
        except:
            return 0.0
    
    def _extract_specifications(self, rod: Dict) -> Dict[str, str]:
        """Extract specifications into a structured dictionary"""
        specs = {}
        
        # Standard specifications mapping
        spec_mapping = {
            "Item Code": "SKU",
            "Brand": "Brand",
            "Model": "Model",
            "Type": "Type",
            "Reel type": "Reel Type",
            "Length": "Length",
            "Joint Type": "Joint Type",
            "Power": "Power",
            "Lure Weight": "Lure Weight",
            "Action": "Action",
            "Material": "Material",
            "Guide": "Guide Type",
            "Reel Seat": "Reel Seat",
            "Warranty": "Warranty",
            "CR": "CR",
            "GV": "GV"
        }
        
        for key, display_name in spec_mapping.items():
            if key in rod and rod[key]:
                specs[display_name] = str(rod[key]).strip()
        
        return specs
    
    def _get_product_images(self, item_code: str) -> List[str]:
        """Get image paths for a product"""
        images = []
        
        # Check for product image folder
        product_folder = config.PRODUCT_IMAGES_DIR / item_code
        if product_folder.exists():
            # Get all image files
            for ext in config.ALLOWED_IMAGE_EXTENSIONS:
                for i in range(1, config.MAX_IMAGES_PER_PRODUCT + 1):
                    img_path = product_folder / f"{i}{ext}"
                    if img_path.exists():
                        # Convert to web URL path
                        web_path = f"/static/product_images/{item_code}/{i}{ext}"
                        images.append(web_path)
        
        # If no images found, use placeholder
        if not images:
            images.append("/static/images/placeholder.jpg")
        
        return images
    
    def get_product_by_id(self, product_id: str) -> Optional[Dict]:
        """Get a single product by ID"""
        data = self.load_products()
        for product in data.get("products", []):
            if product.get("id") == product_id or product.get("sku") == product_id:
                return product
        return None
    
    def get_products_by_category(self, category: str) -> List[Dict]:
        """Get all products in a category"""
        data = self.load_products()
        return [p for p in data.get("products", []) 
                if p.get("category", "").lower() == category.lower()]
    
    def search_products(self, query: str) -> List[Dict]:
        """Search products by title, brand, or model"""
        query = query.lower()
        data = self.load_products()
        
        results = []
        for product in data.get("products", []):
            if (query in product.get("title", "").lower() or
                query in product.get("brand", "").lower() or
                query in product.get("model", "").lower() or
                query in product.get("description", "").lower()):
                results.append(product)
        
        return results
    
    def get_all_categories(self) -> List[str]:
        """Get all product categories"""
        data = self.load_products()
        return data.get("categories", [])
    
    def get_all_brands(self) -> List[str]:
        """Get all product brands"""
        data = self.load_products()
        return data.get("brands", [])

# Create a global instance
product_loader = ProductDataLoader()